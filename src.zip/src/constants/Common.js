'use es6';

export default{
APP_TITLE: 'Follow the weather'
}
