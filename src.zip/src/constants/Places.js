// 'use es6';

const places ={
  DUBLIN:{
    text:'Dublin',
    value:'DUBLIN'
  },
  LONDON:{
    text:'London',
    value:'LONDON'

  },
  NEW_YORK:{
    text:'New York',
    value:'NEW_YORK'

  }

}

export default places;
